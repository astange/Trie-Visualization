package com.project;

import javax.swing.JFrame;

public class TrieDriver {

	/**
	 * Runs the GUI for our Trie
	 * @param args
	 */
	public static void main(String[] args) {
		
		TreePanel treePanel = new TreePanel();
		treePanel.setSize(500, 500);
		treePanel.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		treePanel.setResizable(true);
		treePanel.setVisible(true);
		treePanel.pack();		
	}
}
